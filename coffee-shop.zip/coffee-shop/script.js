document.addEventListener('DOMContentLoaded', () => {

    // --- GLOBAL VARIABLES ---
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    let currentCustomerPhone = null;

    const addButtons = document.querySelectorAll('.add-to-cart');
    const cartButton = document.getElementById('cart-button');
    const cartModal = document.getElementById('cart-modal');
    const closeCartButton = document.getElementById('close-cart');
    const cartItemsContainer = document.getElementById('cart-items');

    const checkoutBtn = document.getElementById('checkout-btn');
    const checkoutModal = document.getElementById('checkout-modal');
    const closeCheckout = document.getElementById('close-checkout');
    const checkoutForm = document.getElementById('checkout-form');
    const orderSummary = document.getElementById('order-summary');

    const viewOrdersBtn = document.getElementById('viewOrdersBtn');

    if (viewOrdersBtn) {
    viewOrdersBtn.addEventListener('click', function() {
        console.log("View orders clicked");
    });
}
    const myOrdersModal = document.getElementById('myorders-modal');

    // --- HELPERS ---
    function enableScroll() { document.body.style.overflow = "auto"; }
    function openCart() { cartModal.style.display = "flex"; document.body.style.overflow = "hidden"; }
    function closeCartFunc() { cartModal.style.display = "none"; enableScroll(); }
    function updateCart() {
        let totalQty = 0, total = 0;
        cartItemsContainer.innerHTML = "";
        cart.forEach((item, index) => {
            totalQty += item.quantity;
            total += item.price * item.quantity;
            cartItemsContainer.innerHTML += `
                <li style="display:flex; justify-content:space-between; margin-bottom:10px; border-bottom:1px solid #eee; padding-bottom:5px;">
                    <span>${item.name} (x${item.quantity})</span>
                    <button onclick="removeItem(${index})" style="background:red;color:white;border:none;border-radius:5px;cursor:pointer;padding:2px 8px;">X</button>
                </li>`;
        });
        document.getElementById("cart-count").innerText = totalQty;
        document.getElementById("cart-total").innerText = total;
    }
    window.removeItem = function(index) { cart.splice(index, 1); localStorage.setItem("cart", JSON.stringify(cart)); updateCart(); }

    // --- ADD TO CART ---
    addButtons.forEach(button => {
        button.addEventListener('click', () => {
            const name = button.dataset.name;
            const price = parseInt(button.dataset.price);
            const existingItem = cart.find(item => item.name === name);
            if(existingItem) existingItem.quantity += 1;
            else cart.push({name, price, quantity:1});
            localStorage.setItem("cart", JSON.stringify(cart));
            updateCart();
        });
    });

    if(cartButton) cartButton.addEventListener('click', openCart);
    if(closeCartButton) closeCartButton.addEventListener('click', closeCartFunc);
    if(cartModal) cartModal.addEventListener('click', e => { if(e.target === cartModal) closeCartFunc(); });

    // --- CHECKOUT ---
    if(checkoutBtn) {
        checkoutBtn.addEventListener('click', () => {
            if(cart.length === 0) { alert("Cart is empty!"); return; }
            let summaryHTML = '<ul style="list-style:none; padding:0; text-align:left;">';
            let total = 0;
            cart.forEach(item => { summaryHTML += `<li>${item.name} (x${item.quantity}) - ₱${item.price * item.quantity}</li>`; total += item.price * item.quantity; });
            summaryHTML += `</ul><hr><p style="text-align:right; font-weight:bold;">Total: ₱${total}</p>`;
            orderSummary.innerHTML = summaryHTML;
            cartModal.style.display = "none";
            enableScroll();
            checkoutModal.style.display = "flex";
        });
    }

    if(closeCheckout) closeCheckout.addEventListener('click', () => { checkoutModal.style.display = "none"; enableScroll(); });

    if(checkoutForm) {
checkoutForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    if(cart.length === 0) {
        alert("Cart is empty!");
        return;
    }

    const orderData = {
        customer_name: document.getElementById('customer-name').value,
        phone: document.getElementById('customer-phone').value,
        email: document.getElementById('customer-email').value,
        address: document.getElementById('customer-address').value,
        items: cart,
        total: cart.reduce((acc,item)=> acc + (item.price*item.quantity),0)
    };

    try {

        const response = await fetch("save_order.php", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(orderData)
        });

        const result = await response.json();

        if(result.success){

            cart = [];
            localStorage.setItem("cart", JSON.stringify(cart));
            updateCart();

            checkoutModal.style.display = "none";
            enableScroll();
            checkoutForm.reset();

            alert("✅ Order saved to database successfully!");

        } else {
            alert("❌ Error saving order!");
        }

    } catch(error){
        console.error(error);
        alert("Server error!");
    }

});
}

    // --- CUSTOMER LOGIN & MY ORDERS ---
    function openLogin() { document.getElementById('login-modal').style.display = 'flex'; }
    window.openLogin = openLogin;
    function closeLogin() { document.getElementById('login-modal').style.display = 'none'; }
    window.closeLogin = closeLogin;

    window.customerLogin = function() {
        const phone = document.getElementById('login-phone').value.replace(/[\s\-]/g,'');
        if(!phone) { alert('Please enter phone number'); return; }
        currentCustomerPhone = phone;
        closeLogin();
        loadMyOrders();
        myOrdersModal.style.display = 'flex';
    }

    window.closeMyOrders = function() { myOrdersModal.style.display = 'none'; }

    window.loadMyOrders = function() {
        const orders = JSON.parse(localStorage.getItem('coffeeOrders')) || [];
        const customerOrders = orders.filter(o => {
            let phone = o.customer.phone.replace(/[\s\-]/g,'');
            return phone.includes(currentCustomerPhone) || currentCustomerPhone.includes(phone);
        });
        const container = document.getElementById('customer-orders-list');
        if(customerOrders.length === 0) { container.innerHTML = '<p style="text-align:center; padding:30px;">No orders found.</p>'; return; }
        let totalPoints = 0;
        container.innerHTML = customerOrders.reverse().map(order => {
            totalPoints += Math.floor(order.total/10);
            return `<div style="background:#f9f9f9; padding:15px; border-radius:10px; margin-bottom:15px;">
                <div style="display:flex; justify-content:space-between;"><strong>Order #${order.id}</strong>
                <span style="padding:5px 10px; border-radius:20px; font-size:12px; background:${getStatusColor(order.status)}; color:white;">${order.status}</span></div>
                <p style="margin:5px 0; color:#666;">${order.date}</p>
                <div style="margin:10px 0;">${order.items.map(i => `<div>• ${i.name} x${i.quantity}</div>`).join('')}</div>
                <div style="display:flex; justify-content:space-between; margin-top:10px;">
                <strong style="color:#f3961c; font-size:18px;">₱${order.total.toLocaleString()}</strong>
                <button onclick="rateOrder(${order.id})" style="background:#ffc107; border:none; padding:5px 15px; border-radius:5px; cursor:pointer;">⭐ Rate</button>
                </div>
                ${order.rating ? `<p style="margin-top:10px;">Your Rating: ${'⭐'.repeat(order.rating)}</p>` : ''}
            </div>`;
        }).join('') + `<div style="background:#3b141c; color:white; padding:15px; border-radius:10px; text-align:center; margin-top:20px;">
            <h3>🎁 Your Loyalty Points</h3><p style="font-size:30px; margin:10px 0;">${totalPoints} Points</p><small>Earn 1 point for every ₱10 spent!</small></div>`;
    }

    window.getStatusColor = function(status) {
        if(status==='Completed') return '#28a745';
        if(status==='Processing') return '#17a2b8';
        if(status==='Cancelled') return '#dc3545';
        return '#ffc107';
    }

    window.rateOrder = function(orderId) {
        const rating = prompt('Rate this order (1-5 stars):','5');
        if(rating && rating >=1 && rating<=5) {
            const orders = JSON.parse(localStorage.getItem('coffeeOrders')) || [];
            const index = orders.findIndex(o => o.id===orderId);
            if(index!==-1) { orders[index].rating = parseInt(rating); localStorage.setItem('coffeeOrders', JSON.stringify(orders)); alert('Thank you for rating!'); loadMyOrders(); }
        }
    }

    // --- VIEW ORDER BUTTON (CART) ---
    if(viewOrdersBtn) {
        viewOrdersBtn.addEventListener('click', () => {
            if(!currentCustomerPhone) { alert("Enter your phone number first!"); openLogin(); return; }
            closeCartFunc();
            loadMyOrders();
            myOrdersModal.style.display = 'flex';
        });
    }

    // --- CLICK OUTSIDE MODALS TO CLOSE ---
    window.addEventListener('click', e => {
        if(e.target === cartModal) closeCartFunc();
        if(e.target === checkoutModal) { checkoutModal.style.display='none'; enableScroll(); }
        if(e.target === myOrdersModal) { myOrdersModal.style.display='none'; enableScroll(); }
        if(e.target === document.getElementById('login-modal')) closeLogin();
    });

    // --- INIT ---
    updateCart();
});

    function updateCart() {
        let totalQty = 0, total = 0;
        cartItemsContainer.innerHTML = "";
        cart.forEach((item, index) => {
            totalQty += item.quantity;
            total += item.price * item.quantity;
            cartItemsContainer.innerHTML += `<li style="display:flex;justify-content:space-between;margin-bottom:10px;border-bottom:1px solid #eee;padding-bottom:5px;"><span>${item.name} (x${item.quantity})</span><button onclick="removeItem(${index})" style="background:red;color:white;border:none;border-radius:5px;cursor:pointer;padding:2px 8px;">X</button></li>`;
        });
        document.getElementById("cart-count").innerText = totalQty;
        document.getElementById("cart-total").innerText = total;
    }
    window.removeItem = function(index) { cart.splice(index, 1); localStorage.setItem("cart", JSON.stringify(cart)); updateCart(); }

    var swiper = new Swiper(".slider-container", { loop: true, spaceBetween: 30, autoplay: { delay: 2500, disableOnInteraction: false }, pagination: { el: ".swiper-pagination", clickable: true }, navigation: { nextEl: ".swiper-button-next", prevEl: ".swiper-button-prev" }, breakpoints: { 0: { slidesPerView: 1 }, 768: { slidesPerView: 2 }, 1024: { slidesPerView: 3 } } });

    const checkoutBtn = document.getElementById('checkout-btn');
    const checkoutModal = document.getElementById('checkout-modal');
    const closeCheckout = document.getElementById('close-checkout');
    const checkoutForm = document.getElementById('checkout-form');
    const orderSummary = document.getElementById('order-summary');
    const viewOrdersBtn = document.getElementById("viewOrdersBtn");
    if(viewOrdersBtn) {
    viewOrdersBtn.addEventListener('click', () => {
        cartModal.style.display = "none"; // close cart
        enableScroll();



        const historyList = document.getElementById('order-history-list');
        if(orders.length === 0) {
            historyList.innerHTML = "<p>No orders yet.</p>";
        } else {
            // show each order with a Remove button
            historyList.innerHTML = orders.reverse().map((order, index) => `
                <div style="border:1px solid #ccc; padding:10px; margin-bottom:10px; border-radius:5px; position:relative;">
                    <strong>Order #${order.id}</strong><br>
                    <small>${order.date}</small><br>
                    <strong>Total: ₱${order.total}</strong><br>
                    <em>Items: ${order.items.map(i => i.name).join(', ')}</em>
                    <button onclick="removeOrder(${orders.length - 1 - index})" 
                            style="position:absolute; top:10px; right:10px; background:red; color:white; border:none; border-radius:5px; cursor:pointer; padding:2px 6px;">
                        X
                    </button>
                </div>
            `).join('');
        }

        // Show the modal
        orderHistoryModal.style.display = "flex";
    });
}

// Function to remove a specific order
window.removeOrder = function(index) {
    let orders = JSON.parse(localStorage.getItem('coffeeOrders')) || [];
    orders.splice(index, 1); // remove selected order
    localStorage.setItem('coffeeOrders', JSON.stringify(orders));
    // refresh the modal
    viewOrdersBtn.click();
}
    const orderHistoryModal = document.getElementById('order-history-modal');
    const closeHistory = document.getElementById('close-history');

    if(checkoutBtn) {
        checkoutBtn.addEventListener('click', () => {
            if(cart.length === 0) { alert("Cart is empty!"); return; }
            let summaryHTML = '<ul style="list-style:none; padding:0; text-align:left;">';
            let total = 0;
            cart.forEach(item => { summaryHTML += `<li>${item.name} (x${item.quantity}) - ₱${item.price * item.quantity}</li>`; total += item.price * item.quantity; });
            summaryHTML += `</ul><hr><p style="text-align:right; font-weight:bold;">Total: ₱${total}</p>`;
            orderSummary.innerHTML = summaryHTML;
            cartModal.style.display = "none";
            enableScroll();
            checkoutModal.style.display = "flex";
        });
    }

    if(closeCheckout) closeCheckout.addEventListener('click', () => { checkoutModal.style.display = "none"; enableScroll(); });

    if(checkoutForm) {
        checkoutForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const order = {
                id: Date.now(),
                date: new Date().toLocaleString(),
                items: cart,
                total: cart.reduce((acc, item) => acc + (item.price * item.quantity), 0),
                customer: { name: document.getElementById('customer-name').value, phone: document.getElementById('customer-phone').value, email: document.getElementById('customer-email').value, address: document.getElementById('customer-address').value },
                status: 'Pending', rating: 0
            };
            let orders = JSON.parse(localStorage.getItem('coffeeOrders')) || [];
            orders.push(order);
            localStorage.setItem('coffeeOrders', JSON.stringify(orders));
            cart = [];
            localStorage.setItem("cart", JSON.stringify(cart));
            updateCart();
            checkoutModal.style.display = "none";
            enableScroll();
            checkoutForm.reset();
            alert("Order placed successfully! Thank you.");
        });
    }

    if(viewOrdersBtn) {
        viewOrdersBtn.addEventListener('click', () => {
            cartModal.style.display = "none";
            enableScroll();
            const orders = JSON.parse(localStorage.getItem('coffeeOrders')) || [];
            const historyList = document.getElementById('order-history-list');
            if(orders.length === 0) historyList.innerHTML = "<p>No orders yet.</p>";
            else {
                historyList.innerHTML = orders.reverse().map(order => `
                    <div style="border:1px solid #ccc; padding:10px; margin-bottom:10px; border-radius:5px;">
                        <strong>Order #${order.id}</strong><br><small>${order.date}</small><br>
                        <strong>Total: ₱${order.total}</strong><br>
                        <span style="padding:3px 8px; border-radius:10px; font-size:12px; background:${getStatusColor(order.status)}; color:white;">${order.status}</span><br>
                        <em>Items: ${order.items.map(i => i.name).join(', ')}</em>
                    </div>`).join('');
            }
            orderHistoryModal.style.display = "flex";
        });
    }

    if(closeHistory) closeHistory.addEventListener('click', () => { orderHistoryModal.style.display = "none"; enableScroll(); });

    window.addEventListener('click', (e) => {
        if (e.target === checkoutModal) { checkoutModal.style.display = "none"; enableScroll(); }
        if (e.target === orderHistoryModal) { orderHistoryModal.style.display = "none"; enableScroll(); }
        if (e.target === document.getElementById('login-modal')) closeLogin();
        if (e.target === document.getElementById('myorders-modal')) closeMyOrders();
        if (e.target === document.getElementById('reservation-modal')) closeReservation();
    });

    // === CUSTOMER LOGIN & MY ORDERS ===
    let currentCustomerPhone = null;
    function openLogin() { document.getElementById('login-modal').style.display = 'flex'; }
    window.openLogin = openLogin;
    function closeLogin() { document.getElementById('login-modal').style.display = 'none'; }
    window.closeLogin = closeLogin;
    function customerLogin() {
        const phone = document.getElementById('login-phone').value.replace(/[\s\-]/g, '');
        if (!phone) { alert('Please enter phone number'); return; }
        currentCustomerPhone = phone;
        closeLogin();
        loadMyOrders();
        document.getElementById('myorders-modal').style.display = 'flex';
    }
    window.customerLogin = customerLogin;
    function closeMyOrders() { document.getElementById('myorders-modal').style.display = 'none'; }
    window.closeMyOrders = closeMyOrders;
    function loadMyOrders() {
        const orders = JSON.parse(localStorage.getItem('coffeeOrders')) || [];
        const customerOrders = orders.filter(o => { let phone = o.customer.phone.replace(/[\s\-]/g, ''); return phone.includes(currentCustomerPhone) || currentCustomerPhone.includes(phone); });
        const container = document.getElementById('customer-orders-list');
        if (customerOrders.length === 0) { container.innerHTML = '<p style="text-align:center; padding:30px;">No orders found.</p>'; return; }
        let totalPoints = 0;
        container.innerHTML = customerOrders.reverse().map(order => {
            totalPoints += Math.floor(order.total / 10);
            return `<div style="background:#f9f9f9; padding:15px; border-radius:10px; margin-bottom:15px;">
                <div style="display:flex; justify-content:space-between;"><strong>Order #${order.id}</strong><span style="padding:5px 10px; border-radius:20px; font-size:12px; background:${getStatusColor(order.status)}; color:white;">${order.status}</span></div>
                <p style="margin:5px 0; color:#666;">${order.date}</p>
                <div style="margin:10px 0;">${order.items.map(i => `<div>• ${i.name} x${i.quantity}</div>`).join('')}</div>
                <div style="display:flex; justify-content:space-between; margin-top:10px;"><strong style="color:#f3961c; font-size:18px;">₱${order.total.toLocaleString()}</strong><button onclick="rateOrder(${order.id})" style="background:#ffc107; border:none; padding:5px 15px; border-radius:5px; cursor:pointer;">⭐ Rate</button></div>
                ${order.rating ? `<p style="margin-top:10px;">Your Rating: ${'⭐'.repeat(order.rating)}</p>` : ''}</div>`;
        }).join('') + `<div style="background:#3b141c; color:white; padding:15px; border-radius:10px; text-align:center; margin-top:20px;"><h3>🎁 Your Loyalty Points</h3><p style="font-size:30px; margin:10px 0;">${totalPoints} Points</p><small>Earn 1 point for every ₱10 spent!</small></div>`;
    }
    window.loadMyOrders = loadMyOrders;
    function getStatusColor(status) { if (status === 'Completed') return '#28a745'; if (status === 'Processing') return '#17a2b8'; if (status === 'Cancelled') return '#dc3545'; return '#ffc107'; }
    window.getStatusColor = getStatusColor;
    window.rateOrder = function(orderId) {
        const rating = prompt('Rate this order (1-5 stars):', '5');
        if (rating && rating >= 1 && rating <= 5) {
            const orders = JSON.parse(localStorage.getItem('coffeeOrders')) || [];
            const orderIndex = orders.findIndex(o => o.id === orderId);
            if (orderIndex !== -1) { orders[orderIndex].rating = parseInt(rating); localStorage.setItem('coffeeOrders', JSON.stringify(orders)); alert('Thank you for rating!'); loadMyOrders(); }
        }
    }

    // === TABLE RESERVATION ===
    function openReservation() { document.getElementById('reservation-modal').style.display = 'flex'; }
    window.openReservation = openReservation;
    function closeReservation() { document.getElementById('reservation-modal').style.display = 'none'; }
    window.closeReservation = closeReservation;
    const reservationForm = document.getElementById('reservation-form');
    if (reservationForm) {
        reservationForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const reservation = { id: Date.now(), name: document.getElementById('res-name').value, phone: document.getElementById('res-phone').value, guests: document.getElementById('res-guests').value, date: document.getElementById('res-date').value, status: 'Pending' };
            let reservations = JSON.parse(localStorage.getItem('tableReservations')) || [];
            reservations.push(reservation);
            localStorage.setItem('tableReservations', JSON.stringify(reservations));
            alert('✅ Table reserved successfully!');
            const msg = `📅 Table Reservation\n\nName: ${reservation.name}\nPhone: ${reservation.phone}\nGuests: ${reservation.guests}\nDate: ${reservation.date}`;
            window.open(`https://wa.me/639525191218?text=${encodeURIComponent(msg)}`, '_blank');
            this.reset();
            closeReservation();
        });
    }

    // Init default menu
    if (!localStorage.getItem('coffeeMenu')) {
        const defaultMenu = [{ name: 'Hot Beverages', price: 120, description: 'Hot coffee', image: 'images/hot-beverages.png' }, { name: 'Cold Beverages', price: 150, description: 'Cold coffee', image: 'images/cold-beverages.png' }, { name: 'Refreshment', price: 130, description: 'Refreshing drinks', image: 'images/refreshment.png' }, { name: 'Special Combos', price: 250, description: 'Combos', image: 'images/special-combo.png' }, { name: 'Desserts', price: 180, description: 'Sweets', image: 'images/desserts.png' }, { name: 'Burger & Fries', price: 200, description: 'Snacks', image: 'images/burger-frenchfries.png' }];
        localStorage.setItem('coffeeMenu', JSON.stringify(defaultMenu));
    }

    updateCart();

document.getElementById("year").textContent = new Date().getFullYear();

function acceptCookies(){
    document.getElementById("cookie-box").style.display = "none";
    localStorage.setItem("cookiesAccepted","true");
}

window.onload = function(){
    if(localStorage.getItem("cookiesAccepted")){
        document.getElementById("cookie-box").style.display = "none";
    }
}

// Contact Form Premium Modal
const contactForm = document.querySelector('.contact-form');
const contactModal = document.getElementById('contact-modal');
const contactModalContent = document.getElementById('contact-modal-content');
const contactModalInner = document.getElementById('contact-modal-inner');
const contactCloseBtn = document.getElementById('contact-close-btn');

const confettiCanvas = document.getElementById('confettiCanvas');
const confettiCtx = confettiCanvas.getContext('2d');
const sparkleCanvas = document.getElementById('sparkleCanvas');
const sparkleCtx = sparkleCanvas.getContext('2d');

let confetti = [];
let sparkles = [];

// Resize canvases
function resizeCanvas() {
  confettiCanvas.width = contactModalContent.offsetWidth;
  confettiCanvas.height = contactModalContent.offsetHeight;
  sparkleCanvas.width = contactModalContent.offsetWidth;
  sparkleCanvas.height = contactModalContent.offsetHeight;
}
window.addEventListener('resize', resizeCanvas);
resizeCanvas();

// Confetti Particle
class ConfettiParticle {
  constructor() {
    this.x = Math.random() * confettiCanvas.width;
    this.y = Math.random() * -confettiCanvas.height;
    this.size = Math.random() * 6 + 4;
    this.speed = Math.random() * 3 + 2;
    const colors = ["#ff4c4c","#ff9f1c","#2ec4b6","#6a11cb","#fcdc00"];
    this.color = colors[Math.floor(Math.random() * colors.length)];
    this.tilt = Math.random() * 10 - 5;
  }
  update() {
    this.y += this.speed;
    this.x += Math.sin(this.y / 10);
    if(this.y > confettiCanvas.height) this.y = -this.size;
  }
  draw() {
    confettiCtx.fillStyle = this.color;
    confettiCtx.beginPath();
    confettiCtx.moveTo(this.x + this.tilt, this.y);
    confettiCtx.lineTo(this.x + this.tilt + this.size/2, this.y + this.size);
    confettiCtx.lineTo(this.x + this.tilt - this.size/2, this.y + this.size);
    confettiCtx.closePath();
    confettiCtx.fill();
  }
}

// Sparkle Particle
class Sparkle {
  constructor() {
    this.x = Math.random() * sparkleCanvas.width;
    this.y = Math.random() * sparkleCanvas.height;
    this.radius = Math.random() * 2 + 0.5;
    this.opacity = Math.random();
    this.speed = Math.random() * 0.02 + 0.01;
  }
  update() {
    this.opacity += this.speed;
    if(this.opacity > 1) { this.opacity = 0; this.x = Math.random()*sparkleCanvas.width; this.y = Math.random()*sparkleCanvas.height; }
  }
  draw() {
    sparkleCtx.fillStyle = `rgba(255,255,255,${this.opacity})`;
    sparkleCtx.beginPath();
    sparkleCtx.arc(this.x,this.y,this.radius,0,Math.PI*2);
    sparkleCtx.fill();
  }
}

// Animation Loops
function animateConfetti() {
  confettiCtx.clearRect(0,0,confettiCanvas.width,confettiCanvas.height);
  confetti.forEach(c => { c.update(); c.draw(); });
  requestAnimationFrame(animateConfetti);
}
function animateSparkles() {
  sparkleCtx.clearRect(0,0,sparkleCanvas.width,sparkleCanvas.height);
  sparkles.forEach(s => { s.update(); s.draw(); });
  requestAnimationFrame(animateSparkles);
}

// Form Submit
contactForm.addEventListener('submit', function(e){
  e.preventDefault(); // prevent real submit
  contactModal.style.display = 'flex';
  setTimeout(()=>{
    contactModal.style.opacity = '1';
    contactModalContent.style.transform = 'scale(1)';
    contactModalInner.style.opacity = '1';
    contactModalInner.style.transform = 'translateY(0)';

    // Start confetti and sparkles
    confetti = [];
    for(let i=0;i<80;i++) confetti.push(new ConfettiParticle());
    animateConfetti();
    sparkles = [];
    for(let i=0;i<60;i++) sparkles.push(new Sparkle());
    animateSparkles();
  },10);
});

// Close modal
contactCloseBtn.addEventListener('click', function(){
  contactModalInner.style.opacity = '0';
  contactModalInner.style.transform = 'translateY(20px)';
  contactModal.style.opacity = '0';
  contactModalContent.style.transform = 'scale(0.8)';
  setTimeout(()=>{ 
    contactModal.style.display='none'; 
    contactForm.reset(); // clear form
  },300);
});