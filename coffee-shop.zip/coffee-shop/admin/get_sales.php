<?php
$conn = new mysqli("localhost","root","","coffee_shop");

$query = "
SELECT DATE(created_at) as order_date,
SUM(total) as daily_sales
FROM orders
GROUP BY DATE(created_at)
ORDER BY DATE(created_at) ASC
";

$result = $conn->query($query);

$data = [];

while($row = $result->fetch_assoc()){
    $data[] = $row;
}

echo json_encode($data);
?>