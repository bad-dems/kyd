<?php
session_start();
include '../includes/db.php';

// Optional: check if admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit();
}

$result = $conn->query("SELECT * FROM orders ORDER BY created_at DESC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
</head>
<body>

<h1>Admin Dashboard - Orders</h1>

<?php
while ($row = $result->fetch_assoc()) {
    echo "<div style='border:1px solid #ccc; padding:10px; margin-bottom:10px;'>";
    echo "<h3>Order #".$row['id']."</h3>";
    echo "<p><strong>Name:</strong> ".$row['full_name']."</p>";
    echo "<p><strong>Phone:</strong> ".$row['phone']."</p>";
    echo "<p><strong>Address:</strong> ".$row['address']."</p>";
    echo "<p><strong>Total:</strong> ₱".$row['total']."</p>";
    echo "<p><strong>Date:</strong> ".$row['created_at']."</p>";
    echo "</div>";
}
?>

</body>
</html>