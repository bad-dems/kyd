<?php

$conn = new mysqli("localhost","root","","coffee_shop");

$data = json_decode(file_get_contents("php://input"), true);

if(!$data){
    echo json_encode(["success"=>false]);
    exit;
}

$customer = $conn->real_escape_string($data["customer_name"]);
$phone = $conn->real_escape_string($data["phone"]);
$email = $conn->real_escape_string($data["email"]);
$address = $conn->real_escape_string($data["address"]);
$total = $data["total"];
$order_id = uniqid("ORD-");

// ✅ Insert into orders table
$conn->query("INSERT INTO orders(order_id, customer_name, phone, address, total)
VALUES('$order_id','$customer','$phone','$address','$total')");

// Get inserted order id
$inserted_id = $conn->insert_id;

// ✅ Insert items
foreach($data["items"] as $item){
    $name = $conn->real_escape_string($item["name"]);
    $price = $item["price"];
    $qty = $item["quantity"];

    $conn->query("INSERT INTO order_items(order_id, product_name, price, quantity)
    VALUES('$order_id','$name','$price','$qty')");
}

echo json_encode(["success"=>true]);

?>