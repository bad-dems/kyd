<!DOCTYPE html>
<html>
<head>
    <title>Your Cart</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<header>
    <h1>Your Cart</h1>
    <div class="cart-icon" onclick="window.location.href='index.php'">
        ← Back to Shop
    </div>
</header>

<div class="cart-container">
    <ul id="cart-items"></ul>
    <h3>Total: ₱<span id="cart-total">0</span></h3>

    <button id="checkout-btn">Proceed to Checkout</button>
</div>

<script src="script.js"></script>
</body>
</html>