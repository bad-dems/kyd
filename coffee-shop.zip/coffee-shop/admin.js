const ADMIN_ACCOUNT = {
    username: "admin",
    password: "admin123"
};

let loginAttempts = 0;
let lockUntil = null;

document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('admin-password').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            adminLogin();
        }
    });
    
    const isLoggedIn = sessionStorage.getItem('adminLoggedIn');
    if (isLoggedIn === 'true') {
        showDashboard();
    }
    
    const loginBox = document.getElementById('loginBox');
    const loginScreen = document.getElementById('login-screen');
    
    if (loginBox && loginScreen) {
        loginScreen.addEventListener('mousemove', (e) => {
            const rect = loginScreen.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            const centerX = rect.width / 2;
            const centerY = rect.height / 2;
            const rotateX = (y - centerY) / 20;
            const rotateY = (centerX - x) / 20;
            loginBox.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale(1.02)`;
        });
        
        loginScreen.addEventListener('mouseleave', () => {
            loginBox.style.transform = 'perspective(1000px) rotateX(0deg) rotateY(0deg) scale(1)';
        });
    }
    
    const modal = document.getElementById('order-modal');
    const modalContent = document.getElementById('modalContent');
    if (modal && modalContent) {
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                closeModal();
            }
        });
    }
});

function adminLogin() {
    const username = document.getElementById('admin-username').value;
    const password = document.getElementById('admin-password').value;
    const errorMsg = document.getElementById('login-error');
    const loginScreen = document.getElementById('login-screen');

    if (lockUntil && Date.now() < lockUntil) {
        errorMsg.style.display = 'block';
        errorMsg.textContent = "Account locked. Try again later.";
        return;
    }

    if (username === ADMIN_ACCOUNT.username && password === ADMIN_ACCOUNT.password) {
        loginAttempts = 0;
        sessionStorage.setItem('adminLoggedIn', 'true');
        loginScreen.style.transition = "opacity 0.5s ease";
        loginScreen.style.opacity = "0";

        setTimeout(() => {
            showDashboard();
            loginScreen.style.opacity = "1";
        }, 500);
    } else {
        loginAttempts++;
        errorMsg.style.display = 'block';
        errorMsg.textContent = "Invalid username or password.";

        if (loginAttempts >= 3) {
            lockUntil = Date.now() + 30000;
            errorMsg.textContent = "Too many attempts. Locked for 30 seconds.";
        }

        const box = document.querySelector('.login-box');
        box.style.animation = 'none';
        box.offsetHeight;
        box.style.animation = 'shake 0.4s ease';
    }
}
window.adminLogin = adminLogin;

function adminLogout() {
    sessionStorage.removeItem('adminLoggedIn');
    document.getElementById('login-screen').style.display = 'flex';
    document.getElementById('admin-dashboard').style.display = 'none';
}
window.adminLogout = adminLogout;

function showDashboard() {
    document.getElementById('login-screen').style.display = 'none';
    document.getElementById('admin-dashboard').style.display = 'block';
    loadOrders();
    loadCustomers();
    loadReservations();
    loadMenu();
    if (typeof renderChart === "function") {
    renderChart();
}
    setInterval(() => { loadOrders(); renderChart(); }, 10000);
}

let currentOrderId = null, currentOrderData = null, allOrders = [];

function switchTab(tabName) {
    if (tabName === "sales") {
    loadSalesChart();
}
    document.querySelectorAll('.tab-content').forEach(tab => tab.classList.remove('active'));
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
    document.getElementById(tabName + '-tab').classList.add('active');
    event.target.classList.add('active');
}
window.switchTab = switchTab;

function loadOrders() {
    allOrders = JSON.parse(localStorage.getItem('coffeeOrders')) || [];
    let totalRevenue = 0, pendingCount = 0, completedCount = 0;
    allOrders.forEach(order => {
        totalRevenue += order.total;
        if(order.status === 'Pending') pendingCount++;
        if(order.status === 'Completed') completedCount++;
    });
    document.getElementById('total-orders').textContent = allOrders.length;
    document.getElementById('total-revenue').textContent = '₱' + totalRevenue.toLocaleString();
    document.getElementById('pending-orders').textContent = pendingCount;
    document.getElementById('completed-orders').textContent = completedCount;
    renderOrdersTable(allOrders);
}
window.loadOrders = loadOrders;

function renderOrdersTable(orders) {
    const tbody = document.getElementById('orders-tbody');
    if (orders.length === 0) {
        tbody.innerHTML = '<tr><td colspan="9" style="text-align:center; padding:30px;">No orders found</td></tr>';
        return;
    }
    
    let html = '';
    orders.reverse().forEach(order => {
        const isCompleted = order.status === 'Completed';
        
        html += '<tr>';
        html += '<td>#' + order.id + '</td>';
        html += '<td>' + order.date + '</td>';
        html += '<td><strong>' + order.customer.name + '</strong></td>';
        html += '<td>' + order.customer.phone + '</td>';
        html += '<td>' + order.customer.address + '</td>';
        html += '<td>' + order.items.map(i => i.name).join(', ') + '</td>';
        html += '<td>₱' + order.total.toLocaleString() + '</td>';
        html += '<td><span class="' + getStatusClass(order.status) + '">' + order.status + '</span></td>';
        html += '<td class="action-btns">';
        html += '<button class="view-btn" onclick="viewOrder(' + order.id + ')">View</button>';
        html += '<button class="print-btn" onclick="printOrderById(' + order.id + ')"><i class="fas fa-print"></i></button>';
        
        if (isCompleted) {
            html += '<button class="delete-btn" onclick="deleteOrder(' + order.id + ')" title="Delete Order">X</button>';
        } else {
            html += '<button class="delete-btn" disabled title="Only completed orders can be deleted" style="opacity:0.5;cursor:not-allowed;">X</button>';
        }
        
        html += '</td>';
        html += '</tr>';
    });
    
    tbody.innerHTML = html;
}
window.renderOrdersTable = renderOrdersTable;

function getStatusClass(status) {
    if (status === 'Pending') return 'status-pending';
    if (status === 'Processing') return 'status-processing';
    if (status === 'Completed') return 'status-completed';
    if (status === 'Cancelled') return 'status-cancelled';
    return 'status-pending';
}
window.getStatusClass = getStatusClass;

function deleteOrder(orderId) {
    const order = allOrders.find(o => o.id === orderId);
    if (!order) return;
    
    if (order.status !== 'Completed') {
        alert('Only completed orders can be deleted!');
        return;
    }
    
    if (confirm('Delete this completed order? This cannot be undone.')) {
        allOrders = allOrders.filter(o => o.id !== orderId);
        localStorage.setItem('coffeeOrders', JSON.stringify(allOrders));
        alert('Order deleted successfully!');
        loadOrders();
    }
}
window.deleteOrder = deleteOrder;

function filterOrders() {
    const search = document.getElementById('search-input').value.toLowerCase();
    const status = document.getElementById('status-filter').value;
    let filtered = allOrders.filter(order => {
        const matchSearch = order.customer.name.toLowerCase().includes(search) || String(order.id).includes(search) || order.customer.phone.includes(search);
        const matchStatus = status === 'all' || order.status === status;
        return matchSearch && matchStatus;
    });
    renderOrdersTable(filtered);
}
window.filterOrders = filterOrders;

function viewOrder(orderId) {
    const order = allOrders.find(o => o.id === orderId);
    if (!order) return;
    currentOrderId = orderId;
    currentOrderData = order;
    const itemsList = order.items.map(item => `<li>${item.name} (x${item.quantity}) - ₱${item.price * item.quantity}</li>`).join('');
    document.getElementById('order-details').innerHTML = `
        <div class="detail-row"><span class="detail-label">Order ID:</span><span>#${order.id}</span></div>
        <div class="detail-row"><span class="detail-label">Date:</span><span>${order.date}</span></div>
        <div class="detail-row"><span class="detail-label">Customer:</span><span>${order.customer.name}</span></div>
        <div class="detail-row"><span class="detail-label">Phone:</span><span>${order.customer.phone}</span></div>
        <div class="detail-row"><span class="detail-label">Email:</span><span>${order.customer.email || 'N/A'}</span></div>
        <div class="detail-row"><span class="detail-label">Address:</span><span>${order.customer.address}</span></div>
        <div class="detail-row"><span class="detail-label">Items:</span><ul style="margin:5px 0; padding-left:20px;">${itemsList}</ul></div>
        <div class="detail-row"><span class="detail-label">Total:</span><span style="font-weight:bold; color:#f3961c; font-size:18px;">₱${order.total.toLocaleString()}</span></div>
    `;
    document.getElementById('status-select').value = order.status;
    document.getElementById('order-modal').style.display = 'block';
    setTimeout(() => { document.getElementById('modalContent').classList.add('show'); }, 10);
}
window.viewOrder = viewOrder;

function closeModal() {
    const modal = document.getElementById('order-modal');
    modal.style.display = 'none';
}
window.closeModal = closeModal;

function updateStatus() {
    if (!currentOrderId) return;
    const newStatus = document.getElementById('status-select').value;
    const orderIndex = allOrders.findIndex(o => o.id === currentOrderId);
    if (orderIndex !== -1) {
        allOrders[orderIndex].status = newStatus;
        localStorage.setItem('coffeeOrders', JSON.stringify(allOrders));
        currentOrderData = allOrders[orderIndex];
        alert('Status updated to: ' + newStatus);
        closeModal();
        loadOrders();
    }
}
window.updateStatus = updateStatus;

// ===== PRINT ORDER BY ID =====
function printOrderById(orderId) {

    const orders = JSON.parse(localStorage.getItem('coffeeOrders')) || [];

    const order = orders.find(o => o.id === orderId);

    if (!order) {
        alert("Order not found");
        return;
    }

    currentOrderId = orderId;
    currentOrderData = order;

    openReceipt(currentOrderData);
}

function printOrder() {
    const orders = JSON.parse(localStorage.getItem('coffeeOrders')) || [];
    const order = orders.find(o => o.id === currentOrderId);
    if (!order) return;

    openReceipt(order);
}

function printOrderData(order) {

    let printWindow = window.open("", "", "width=800,height=600");

    printWindow.document.write(`
        <html>
        <head>
            <title>Print Receipt</title>
            <style>
                body { font-family: Arial; padding: 20px; }
                h2 { text-align: center; }
                .line { border-bottom: 1px dashed #000; margin: 10px 0; }
            </style>
        </head>
        <body>
            <h2>Coffee Shop Receipt</h2>
            <div class="line"></div>
            <p><strong>Order ID:</strong> ${order.id}</p>
            <p><strong>Date:</strong> ${order.date}</p>
            <p><strong>Customer:</strong> ${order.customer}</p>
            <p><strong>Contact:</strong> ${order.contact}</p>
            <p><strong>Address:</strong> ${order.address}</p>
            <div class="line"></div>
            <p><strong>Items:</strong></p>
            ${order.items.map(item => `<p>${item.name} x${item.qty}</p>`).join("")}
            <div class="line"></div>
            <h3>Total: ₱${order.total}</h3>
        </body>
        </html>
    `);

    printWindow.document.close();
    printWindow.print();
}
window.printOrderById = printOrderById;

function printOrderData(order) {
    let itemsList = '';
    order.items.forEach(item => {
        itemsList += '<tr>';
        itemsList += '<td>' + item.name + '</td>';
        itemsList += '<td style="text-align:center;">' + item.quantity + '</td>';
        itemsList += '<td style="text-align:right;">₱' + item.price + '</td>';
        itemsList += '<td style="text-align:right;">₱' + (item.price * item.quantity) + '</td>';
        itemsList += '</tr>';
    });

    const receiptHTML = '<!DOCTYPE html><html><head><title>Official Receipt - Order #' + order.id + '</title><link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet"><style>* { margin: 0; padding: 0; box-sizing: border-box; }body { font-family: "Poppins", sans-serif; padding: 20px; max-width: 300px; margin: 0 auto; color: #333; }.receipt-header { text-align: center; padding-bottom: 15px; border-bottom: 2px dashed #333; margin-bottom: 15px; }.receipt-header h1 { font-size: 24px; color: #3b141c; margin-bottom: 5px; }.receipt-header p { font-size: 12px; color: #666; }.customer-info { margin-bottom: 15px; font-size: 12px; }.customer-info strong { display: block; margin-bottom: 3px; }table { width: 100%; border-collapse: collapse; font-size: 12px; margin-bottom: 15px; }table th { border-bottom: 1px solid #333; padding: 5px; text-align: left; }table td { padding: 5px; }.total-section { border-top: 2px solid #333; padding-top: 10px; text-align: right; }.total-label { font-size: 14px; font-weight: 600; }.total-amount { font-size: 20px; font-weight: 700; color: #3b141c; }.footer { text-align: center; margin-top: 20px; padding-top: 15px; border-top: 2px dashed #333; font-size: 11px; color: #666; }.status-badge { display: inline-block; padding: 3px 10px; background: #28a745; color: white; border-radius: 3px; font-size: 10px; margin-top: 10px; }</style></head><body>';
    receiptHTML += '<div class="receipt-header"><h1>☕ COFFEE SHOP</h1><p>Cotabato State University</p><p>Tel: 0994-249-8562</p></div>';
    receiptHTML += '<div class="customer-info"><strong>Order #: ' + order.id + '</strong><strong>Date: ' + order.date + '</strong><strong>Customer: ' + order.customer.name + '</strong><strong>Phone: ' + order.customer.phone + '</strong><strong>Address: ' + order.customer.address + '</strong></div>';
    receiptHTML += '<table><thead><tr><th>Item</th><th style="text-align:center;">Qty</th><th style="text-align:right;">Price</th><th style="text-align:right;">Total</th></tr></thead><tbody>' + itemsList + '</tbody></table>';
    receiptHTML += '<div class="total-section"><div class="total-label">TOTAL:</div><div class="total-amount">₱' + order.total.toLocaleString() + '</div><div class="status-badge">' + order.status + '</div></div>';
    receiptHTML += '<div class="footer"><p>Thank you for your order!</p><p>Please come again ☕</p></div>';
    receiptHTML += '</body></html>';

    const printWindow = window.open('', '_blank');
    printWindow.document.write(receiptHTML);
    printWindow.document.close();
}
window.printOrderData = printOrderData;

function sendWhatsApp() {
    if (!currentOrderData) return;
    const order = currentOrderData;
    const status = document.getElementById('status-select').value;
    let statusMessage = status === 'Processing' ? 'Being prepared!' : status === 'Completed' ? 'Ready!' : status === 'Cancelled' ? 'Cancelled.' : 'Pending.';
    const message = `Coffee Shop Update\n\nHi ${order.customer.name}!\n\nOrder #${order.id}\nStatus: ${status}\n\n${statusMessage}\n\nTotal: ₱${order.total.toLocaleString()}\n\nThanks!`;
    let phone = order.customer.phone.replace(/[\s\-]/g, '');
    if (phone.startsWith('0')) phone = '63' + phone.substring(1);
    else if (!phone.startsWith('63')) phone = '63' + phone;
    window.open(`https://wa.me/${phone}?text=${encodeURIComponent(message)}`, '_blank');
}
window.sendWhatsApp = sendWhatsApp;

function loadCustomers() {
    const orders = JSON.parse(localStorage.getItem('coffeeOrders')) || [];
    const customerMap = {};
    orders.forEach(order => {
        const phone = order.customer.phone;
        if (!customerMap[phone]) {
            customerMap[phone] = { name: order.customer.name, phone: phone, orders: [], totalSpent: 0 };
        }
        customerMap[phone].orders.push(order.id);
        customerMap[phone].totalSpent += order.total;
    });
    const customers = Object.values(customerMap);
    const container = document.getElementById('customers-list');
    if (customers.length === 0) {
        container.innerHTML = '<p>No customers.</p>';
        return;
    }
    container.innerHTML = customers.map(c => `<div class="customer-card"><h3>${c.name}</h3><p><strong>Phone:</strong> ${c.phone}</p><p><strong>Orders:</strong> ${c.orders.length}</p><p><strong>Spent:</strong> ₱${c.totalSpent.toLocaleString()}</p></div>`).join('');
        container.innerHTML = customers.map(c => `<div class="customer-card"><h3>${c.name}</h3><p><strong>Phone:</strong> ${c.phone}</p><p><strong>Orders:</strong> ${c.orders.length}</p><p><strong>Spent:</strong> ₱${c.totalSpent.toLocaleString()}</p></div>`).join('');
}
window.loadCustomers = loadCustomers;

function filterCustomers() {
    const search = document.getElementById('customer-search').value.toLowerCase();
    const orders = JSON.parse(localStorage.getItem('coffeeOrders')) || [];
    const customerMap = {};
    orders.forEach(order => {
        const phone = order.customer.phone;
        if (!customerMap[phone]) {
            customerMap[phone] = { name: order.customer.name, phone: phone, orders: [], totalSpent: 0 };
        }
        customerMap[phone].orders.push(order.id);
        customerMap[phone].totalSpent += order.total;
    });
    let customers = Object.values(customerMap).filter(c => c.name.toLowerCase().includes(search) || c.phone.includes(search));
    document.getElementById('customers-list').innerHTML = customers.map(c => `<div class="customer-card"><h3>${c.name}</h3><p><strong>Phone:</strong> ${c.phone}</p><p><strong>Orders:</strong> ${c.orders.length}</p><p><strong>Spent:</strong> ₱${c.totalSpent.toLocaleString()}</p></div>`).join('');
}
window.filterCustomers = filterCustomers;

// ===== SALES CHART SAFE VERSION =====
let salesChartInstance = null;
let currentChartType = "bar";
let darkMode = false;

function calculateSales() {
    const orders = JSON.parse(localStorage.getItem("coffeeOrders")) || [];

    let weekly = 0;
    let monthly = 0;
    let yearly = 0;

    const now = new Date();
    const currentMonth = now.getMonth();
    const currentYear = now.getFullYear();

    orders.forEach(order => {
        const orderDate = new Date(order.date);
        yearly += order.total;

        if (orderDate.getMonth() === currentMonth &&
            orderDate.getFullYear() === currentYear) {
            monthly += order.total;
        }

        const diff = (now - orderDate) / (1000 * 60 * 60 * 24);
        if (diff <= 7) {
            weekly += order.total;
        }
    });

    document.getElementById("weeklySales").textContent = "₱" + weekly.toLocaleString();
    document.getElementById("monthlySales").textContent = "₱" + monthly.toLocaleString();
    document.getElementById("yearlySales").textContent = "₱" + yearly.toLocaleString();
}

function calculateSales() {
    const orders = JSON.parse(localStorage.getItem("coffeeOrders")) || [];

    let weekly = 0;
    let monthly = 0;
    let yearly = 0;

    const now = new Date();
    const currentMonth = now.getMonth();
    const currentYear = now.getFullYear();

    orders.forEach(order => {
        const orderDate = new Date(order.date);
        yearly += order.total;

        if (orderDate.getMonth() === currentMonth &&
            orderDate.getFullYear() === currentYear) {
            monthly += order.total;
        }

        const diff = (now - orderDate) / (1000 * 60 * 60 * 24);
        if (diff <= 7) {
            weekly += order.total;
        }
    });

    document.getElementById("weeklySales").textContent = "₱" + weekly.toLocaleString();
    document.getElementById("monthlySales").textContent = "₱" + monthly.toLocaleString();
    document.getElementById("yearlySales").textContent = "₱" + yearly.toLocaleString();
}

function loadSalesChart(type = "bar") {

    const ctx = document.getElementById("salesChart").getContext("2d");
    const orders = JSON.parse(localStorage.getItem("coffeeOrders")) || [];

    if (salesChartInstance) {
        salesChartInstance.destroy();
    }

    const monthlyTotals = {};

    orders.forEach(order => {
        const date = new Date(order.date);
        const month = date.toLocaleString("default", { month: "short" });

        if (!monthlyTotals[month]) monthlyTotals[month] = 0;
        monthlyTotals[month] += order.total;
    });

    const labels = Object.keys(monthlyTotals);
    const values = Object.values(monthlyTotals);

    salesChartInstance = new Chart(ctx, {
        type: type === "mixed" ? "bar" : type,
        data: {
            labels: labels,
            datasets: [{
                label: "Monthly Sales (₱)",
                data: values,
                backgroundColor: "#3b141c",
                borderRadius: 20
            }]
        },
        options: {
            responsive: true,
            animation: {
                duration: 2000,
                easing: "easeOutElastic"
            }
        }
    });

    calculateSales();
    generateCalendar();
}

function setChartType(type) {
    currentChartType = type;
    loadSalesChart(type);
}

function toggleDarkMode() {
    darkMode = !darkMode;
    document.body.style.background =
        darkMode ? "#1e1e1e" : "#f4f4f4";

    loadSalesChart(currentChartType);
}

function generateCalendar() {

    const container = document.getElementById("salesCalendar");
    container.innerHTML = "";

    const orders = JSON.parse(localStorage.getItem("coffeeOrders")) || [];
    const today = new Date();
    const year = today.getFullYear();
    const month = today.getMonth();

    const daysInMonth = new Date(year, month + 1, 0).getDate();

    for (let d = 1; d <= daysInMonth; d++) {

        let total = 0;

        orders.forEach(order => {
            const date = new Date(order.date);
            if (
                date.getDate() === d &&
                date.getMonth() === month &&
                date.getFullYear() === year
            ) {
                total += order.total;
            }
        });

        const div = document.createElement("div");
        div.className = "calendar-day";
        div.innerHTML = `<strong>${d}</strong><br>₱${total}`;
        container.appendChild(div);
    }
}

setInterval(() => {
    loadSalesChart(currentChartType);
}, 5000);

loadSalesChart();

function setChartType(type) {
    currentChartType = type;
    loadSalesChart(type);
}

function toggleDarkMode() {
    darkMode = !darkMode;
    document.body.style.background = darkMode ? "#1e1e1e" : "#f4f4f4";
    loadSalesChart(currentChartType);
}

function loadSalesChart(type = "bar") {
    const ctx = document.getElementById("salesChart");
    if (!ctx) return;

    const orders = JSON.parse(localStorage.getItem("coffeeOrders")) || [];

    if (salesChartInstance) {
        salesChartInstance.destroy();
    }

    const monthlyData = getMonthlySales(orders);
    const labels = Object.keys(monthlyData);
    const dataValues = Object.values(monthlyData);

    const gradient = ctx.getContext("2d").createLinearGradient(0, 0, 0, 400);
    gradient.addColorStop(0, "#6a11cb");
    gradient.addColorStop(1, "#2575fc");

    let config = {
        type: type === "mixed" ? "bar" : type,
        data: {
            labels: labels,
            datasets: []
        },
        options: {
            responsive: true,
            animation: {
                duration: 1500,
                easing: "easeOutBounce"
            },
            plugins: {
                legend: {
                    labels: {
                        color: darkMode ? "#fff" : "#000"
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        color: darkMode ? "#fff" : "#000"
                    },
                    grid: {
                        color: darkMode
                            ? "rgba(255,255,255,0.1)"
                            : "rgba(0,0,0,0.05)"
                    }
                },
                x: {
                    ticks: {
                        color: darkMode ? "#fff" : "#000"
                    }
                }
            }
        }
    };

    if (type === "bar") {
        config.data.datasets.push({
            label: "Monthly Sales (₱)",
            data: dataValues,
            backgroundColor: gradient,
            borderRadius: 12,
            borderSkipped: false
        });
    }

    if (type === "line") {
        config.data.datasets.push({
            label: "Revenue Trend",
            data: dataValues,
            borderColor: "#6a11cb",
            backgroundColor: "rgba(106,17,203,0.2)",
            tension: 0.4,
            fill: true
        });
    }

    if (type === "mixed") {
        config.data.datasets.push({
            type: "bar",
            label: "Sales",
            data: dataValues,
            backgroundColor: gradient,
            borderRadius: 10
        });

        config.data.datasets.push({
            type: "line",
            label: "Trend",
            data: dataValues,
            borderColor: "#ff9800",
            tension: 0.4
        });
    }

    salesChartInstance = new Chart(ctx, config);
}

function setChartType(type) {
    currentChartType = type;
    loadSalesChart(type);
}

function toggleDarkMode() {
    darkMode = !darkMode;
    document.body.classList.toggle("dark-mode");
    loadSalesChart(currentChartType);
}
window.renderChart = renderChart;

function loadMenu() {
    const menu = JSON.parse(localStorage.getItem('coffeeMenu')) || [];
    const grid = document.getElementById('menu-grid');
    if (!grid) return;
    if (menu.length === 0) {
        grid.innerHTML = '<p>No menu items.</p>';
        return;
    }
    grid.innerHTML = menu.map((item, index) => `<div class="menu-card"><img src="${item.image}" alt="${item.name}"><h3>${item.name}</h3><p>${item.description}</p><div class="price">₱${item.price}</div><div class="actions"><button class="edit-btn" onclick="editMenuItem(${index})">Edit</button><button class="delete-menu-btn" onclick="deleteMenuItem(${index})">Delete</button></div></div>`).join('');
}
window.loadMenu = loadMenu;

function addMenuItem() {
    const name = document.getElementById('new-menu-name').value;
    const price = document.getElementById('new-menu-price').value;
    const desc = document.getElementById('new-menu-desc').value;
    const img = document.getElementById('new-menu-img').value || 'images/coffee-hero-section.png';
    if (!name || !price) {
        alert('Enter name and price');
        return;
    }
    const menu = JSON.parse(localStorage.getItem('coffeeMenu')) || [];
    menu.push({ name, price: parseInt(price), description: desc, image: img });
    localStorage.setItem('coffeeMenu', JSON.stringify(menu));
    alert('Added!');
    ['new-menu-name','new-menu-price','new-menu-desc','new-menu-img'].forEach(id => document.getElementById(id).value = '');
    loadMenu();
}
window.addMenuItem = addMenuItem;

function editMenuItem(index) {
    const menu = JSON.parse(localStorage.getItem('coffeeMenu')) || [];
    const item = menu[index];
    const newName = prompt('Name:', item.name);
    const newPrice = prompt('Price:', item.price);
    const newDesc = prompt('Description:', item.description);
    if (newName && newPrice) {
        menu[index] = { name: newName, price: parseInt(newPrice), description: newDesc, image: item.image };
        localStorage.setItem('coffeeMenu', JSON.stringify(menu));
        loadMenu();
    }
}
window.editMenuItem = editMenuItem;

function deleteMenuItem(index) {
    if (confirm('Delete?')) {
        const menu = JSON.parse(localStorage.getItem('coffeeMenu')) || [];
        menu.splice(index, 1);
        localStorage.setItem('coffeeMenu', JSON.stringify(menu));
        loadMenu();
    }
}
window.deleteMenuItem = deleteMenuItem;

function loadReservations() {
    const reservations = JSON.parse(localStorage.getItem('tableReservations')) || [];
    const tbody = document.getElementById('reservations-tbody');
    if (!tbody) return;
    tbody.innerHTML = reservations.length === 0 ? '<tr><td colspan="6">No reservations</td></tr>' : reservations.reverse().map(res => `<tr><td>#${res.id}</td><td>${res.name}</td><td>${res.phone}</td><td>${res.guests}</td><td>${res.date}</td><td><span class="status-pending">${res.status}</span></td></tr>`).join('');
}
window.loadReservations = loadReservations;

function openReceipt(order) {

    let itemsText = '';

    if (order.items && order.items.length > 0) {
        order.items.forEach(item => {
            itemsText += `
                <tr>
                    <td>${item.name}</td>
                    <td>${item.quantity}</td>
                    <td>₱${(item.price * item.quantity).toLocaleString()}</td>
                </tr>
            `;
        });
    }

    const receiptWindow = window.open('', '', 'width=800,height=600');

    receiptWindow.document.write(`
        <html>
        <head>
            <title>Receipt</title>
            <style>
                body { font-family: Arial; padding:20px; }
                h2 { text-align:center; }
                table { width:100%; border-collapse: collapse; margin-top:20px; }
                th, td { border:1px solid #ccc; padding:8px; text-align:center; }
                .total { text-align:right; margin-top:20px; font-weight:bold; font-size:18px; }
            </style>
        </head>
        <body>

            <h2>Coffee Shop Receipt</h2>

            <p><strong>Order ID:</strong> #${order.id}</p>
            <p><strong>Date:</strong> ${order.date}</p>
            <p><strong>Customer:</strong> ${order.customer.name}</p>
            <p><strong>Phone:</strong> ${order.customer.phone}</p>
            <p><strong>Email:</strong> ${order.customer.email || ''}</p>
            <p><strong>Address:</strong> ${order.customer.address}</p>

            <table>
                <tr>
                    <th>Item</th>
                    <th>Qty</th>
                    <th>Price</th>
                </tr>
                ${itemsText}
            </table>

            <div class="total">
                Total: ₱${order.total.toLocaleString()}
            </div>

            <script>
                window.print();
            <\/script>

        </body>
        </html>
    `);

    receiptWindow.document.close();
}

function calculateSales() {
    const orders = JSON.parse(localStorage.getItem("coffeeOrders")) || [];

    let weekly = 0;
    let monthly = 0;
    let yearly = 0;

    const now = new Date();
    const currentMonth = now.getMonth();
    const currentYear = now.getFullYear();

    orders.forEach(order => {
        const orderDate = new Date(order.date);
        yearly += order.total;

        if (orderDate.getMonth() === currentMonth &&
            orderDate.getFullYear() === currentYear) {
            monthly += order.total;
        }

        const diff = (now - orderDate) / (1000 * 60 * 60 * 24);
        if (diff <= 7) {
            weekly += order.total;
        }
    });

    document.getElementById("weeklySales").textContent = "₱" + weekly.toLocaleString();
    document.getElementById("monthlySales").textContent = "₱" + monthly.toLocaleString();
    document.getElementById("yearlySales").textContent = "₱" + yearly.toLocaleString();
}

function loadSalesChart(type = "bar") {

    const ctx = document.getElementById("salesChart").getContext("2d");
    const orders = JSON.parse(localStorage.getItem("coffeeOrders")) || [];

    if (salesChartInstance) {
        salesChartInstance.destroy();
    }

    const monthlyTotals = {};

    orders.forEach(order => {
        const date = new Date(order.date);
        const month = date.toLocaleString("default", { month: "short" });

        if (!monthlyTotals[month]) monthlyTotals[month] = 0;
        monthlyTotals[month] += order.total;
    });

    const labels = Object.keys(monthlyTotals);
    const values = Object.values(monthlyTotals);

    salesChartInstance = new Chart(ctx, {
        type: type === "mixed" ? "bar" : type,
        data: {
            labels: labels,
            datasets: [{
                label: "Monthly Sales (₱)",
                data: values,
                backgroundColor: "#3b141c",
                borderRadius: 20
            }]
        },
        options: {
            responsive: true,
            animation: {
                duration: 2000,
                easing: "easeOutElastic"
            }
        }
    });

    calculateSales();
    generateCalendar();
}

function setChartType(type) {
    currentChartType = type;
    loadSalesChart(type);
}

function toggleDarkMode() {
    darkMode = !darkMode;
    document.body.style.background =
        darkMode ? "#1e1e1e" : "#f4f4f4";

    loadSalesChart(currentChartType);
}

function generateCalendar() {

    const container = document.getElementById("salesCalendar");
    container.innerHTML = "";

    const orders = JSON.parse(localStorage.getItem("coffeeOrders")) || [];
    const today = new Date();
    const year = today.getFullYear();
    const month = today.getMonth();

    const daysInMonth = new Date(year, month + 1, 0).getDate();

    for (let d = 1; d <= daysInMonth; d++) {

        let total = 0;

        orders.forEach(order => {
            const date = new Date(order.date);
            if (
                date.getDate() === d &&
                date.getMonth() === month &&
                date.getFullYear() === year
            ) {
                total += order.total;
            }
        });

        const div = document.createElement("div");
        div.className = "calendar-day";
        div.innerHTML = `<strong>${d}</strong><br>₱${total}`;
        container.appendChild(div);
    }
}

setInterval(() => {
    loadSalesChart(currentChartType);
}, 5000);

loadSalesChart();
